module.exports = {
    uri: "mongodb://ro:1234@ds161041.mlab.com:61041/videoplayer",
    secret: "jJIDFIJS889@$%iafjijakjJJ*9ikjfdsajjHH"
}